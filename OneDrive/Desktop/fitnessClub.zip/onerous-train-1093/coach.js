let btn=document.querySelector("#des");
btn.addEventListener("click",function (){
    window.location.href="payment.html"
});
document.querySelector("#des2").addEventListener("click",function (){
    window.location.href="payment.html"
})
document.querySelector("#des3").addEventListener("click",function (){
    window.location.href="payment.html"
})
document.querySelector("#des4").addEventListener("click",function (){
    window.location.href="payment.html"
})
document.querySelector("#des5").addEventListener("click",function (){
    window.location.href="payment.html"
})
document.querySelector("#des6").addEventListener("click",function (){
    window.location.href="payment.html"
})
document.querySelector("#last").addEventListener("click",function (){
    window.location.href="payment.html"
})